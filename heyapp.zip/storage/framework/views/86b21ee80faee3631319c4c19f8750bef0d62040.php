

    <div class="single-point">
        <table class="table">
            <tr>
                <td class="left--col">Full Name</td>
                <td class="right--col"><input getformid="student--form--" type="text" class="get_fullNameVal form-control" placeholder="Full Name"></td>
            </tr>
            <tr>
                <td class="left--col">Degree</td>
                <td class="right--col">
                    <select getformid="student--form--" class="form-control selectOption_">
                        <option value="">Select One</option>
                        <option value="Bachelor">Bachelor</option>
                        <option value="Master">Master</option>
                    </select>
                </td>
            </tr>
        </table>
    </div> <!-- .single-point end here -->

    <form class="myForm__" action="<?php echo e(route('online-requests.store')); ?>" method="POST" 
        id="student--form--Bachelor" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="registration_type" value="Student">
        <input type="hidden" name="full_name" value="" class="set_full_name_val">
        <input type="hidden" name="degree" value="Bachelor">
        <div class="wapper_ Bachelor--warpper d-none">
           <?php echo $__env->make('frontend/partials/student/bachelor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </div>
    </form>

    <form class="myForm__" action="<?php echo e(route('online-requests.store')); ?>" method="POST" 
        id="student--form--Master" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="registration_type" value="Student">
        <input type="hidden" name="full_name" value="" class="set_full_name_val">
        <input type="hidden" name="degree" value="Master">
        <div class="wapper_ Master--warpper d-none">
            <?php echo $__env->make('frontend/partials/student/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </form>


    
<?php /**PATH C:\Users\FREELANCER HRIDOY\online_registration\resources\views/frontend/partials/student/student-index.blade.php ENDPATH**/ ?>