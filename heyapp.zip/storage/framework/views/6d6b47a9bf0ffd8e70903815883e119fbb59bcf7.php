<button title="Edit" type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAdmin-<?php echo e($content->id); ?>">
  <i class="fas fa-edit"></i>
</button>
<!-- Modal -->
<div class="modal fade" id="editAdmin-<?php echo e($content->id); ?>" tabindex="-1" aria-labelledby="editAdminlabel-<?php echo e($content->id); ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editAdminlabel-<?php echo e($content->id); ?>">Edit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.admins.update', $content->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label>Name</label>
            <br>
            <input type="text" name="name" value="<?php echo e($content->name); ?>" class="form-control">
          </div>
          <div class="form-group">
            <label>Email</label>
            <br>
            <input type="email" name="email" value="<?php echo e($content->email); ?>" class="form-control">
          </div>
          <div class="form-group">
            <label>Note</label>
            <br>
            <input type="text" name="note" value="<?php echo e($content->note); ?>" class="form-control" maxlength="200">
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary btn-sm">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/Pages/admins-partials/edit.blade.php ENDPATH**/ ?>