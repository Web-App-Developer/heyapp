<div id="form_processing_gif">
	<img src="/processing/processing.gif">
</div>

<?php /**PATH C:\Users\FREELANCER HRIDOY\online_registration\resources\views/processing/processing-gif.blade.php ENDPATH**/ ?>