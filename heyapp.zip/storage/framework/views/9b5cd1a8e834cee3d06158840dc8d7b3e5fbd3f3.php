<?php echo $__env->make('BackendViews.Admin.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent("adminContent"); ?>

<?php echo $__env->make('BackendViews.Admin.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/layouts/master.blade.php ENDPATH**/ ?>