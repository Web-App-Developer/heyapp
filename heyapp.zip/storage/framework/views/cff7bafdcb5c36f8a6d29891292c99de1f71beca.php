

<?php $__env->startSection('adminContent'); ?>      
<?php echo $__env->make('BackendViews.Admin.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
<!-- yield content here -->
<h3 class="text-center"><b>Welcome</b>- Admin, have a good day!</h3>
	

	
    

<?php $__env->stopSection(); ?>     
<?php echo $__env->make('BackendViews.Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\heyapp\resources\views/BackendViews/Admin/dashboard.blade.php ENDPATH**/ ?>