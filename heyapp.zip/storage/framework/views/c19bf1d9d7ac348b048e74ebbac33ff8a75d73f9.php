<div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <!-- <img class="img-xs rounded-circle" src="<?php echo e(asset('images/backend/images/profile-images/05.jpg')); ?>" alt="profile image"> -->
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo e(Auth::user()->name); ?></p>
                  <p class="designation text-center">Admin</p>
                </div>
              </a>
            </li>
            <li class="nav-item nav-category">Main Menu</li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">
                <span class="menu-title">Dashboard</span>
              </a>
            </li>

            <li class="nav-item">
              <?php
                $getTotalNew = (\App\OnlineRegistration::where('status', 'New')->count());
                $getTotalInProgress = (\App\OnlineRegistration::where('status', 'In progress')->count());
                $getTotalSolved = (\App\OnlineRegistration::where('status', 'Solved')->count());
                $getTotalTrash = (\App\OnlineRegistration::where('status', 'Trash')->count());
              ?>
              <a class="nav-link" data-toggle="collapse" href="#ads" aria-expanded="false" aria-controls="ads">
                <span class="menu-title">Online Requests <?php if($getTotalNew > 0): ?> <span class="badge badge-pill badge-info"><?php echo e($getTotalNew); ?></span><?php endif; ?></span>
                <i class="fas fa-angle-down menu_down_icons"></i>
              </a>
              <div class="collapse" id="ads">
                <ul class="nav flex-column sub-menu">
                    <!--in table page_contents must be the content for file name will be the same to same page url-->
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.newRequests.get')); ?>">Inbox <?php echo e($getTotalNew); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.inProgressRequests.get')); ?>">In Progress <?php echo e($getTotalInProgress); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.solvedRequests.get')); ?>">Solved <?php echo e($getTotalSolved); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.trashedRequests.get')); ?>">Trashed <?php echo e($getTotalTrash); ?></a>
                  </li>
                </ul>
              </div>
            </li>
            
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
        <div id="display_top_search_result_here"></div><?php /**PATH C:\wamp64\www\heyapp\resources\views/BackendViews/Admin/layouts/partials/sidebar.blade.php ENDPATH**/ ?>