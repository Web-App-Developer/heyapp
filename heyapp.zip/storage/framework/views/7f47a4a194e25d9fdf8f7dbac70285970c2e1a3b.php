<div id="form_processing_gif">
	<img src="/processing/processing.gif">
</div>

<?php /**PATH C:\wamp64\www\heyapp\resources\views/processing/processing-gif.blade.php ENDPATH**/ ?>