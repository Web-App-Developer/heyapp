<div id="form_processing_gif">
	<img src="/processing/processing.gif">
</div>

