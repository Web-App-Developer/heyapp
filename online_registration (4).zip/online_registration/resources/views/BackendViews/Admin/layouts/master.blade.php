@include('BackendViews.Admin.layouts.partials.header')

@yield("adminContent")

@include('BackendViews.Admin.layouts.partials.footer')