<div class="details--page">
	<div class="header_">
		<div class="d-flex justify-content-between">
			<div>
				<h4><span><?php echo e($content->registration_type); ?></span>, <span><?php echo e($content->created_at->format('d/m/Y')); ?></span>, <span>#<?php echo e($content->request_id); ?></span></h4>
			</div>
			<?php if(Request::is('admin/inbox')): ?>
			<div>
				<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#adminListModal_in_progress-<?php echo e($content->id); ?>">
				  In Progress
				</button>
				<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#adminListModal_solved-<?php echo e($content->id); ?>">
				  Solved
				</button>
				<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#adminListModal_trashed-<?php echo e($content->id); ?>">
				  Trash
				</button>
			</div>
			<?php endif; ?>

			<?php if(Request::is('admin/trashed')): ?>
				<?php if(Auth::user()->type === "SuperAdmin"): ?>
					<form action="<?php echo e(route('admin.moveTo.post', $content->id)); ?>" method="POST">
			        	<?php echo csrf_field(); ?>
			        	<input type="hidden" name="move_to" value="Delete">
			        	<input type="hidden" name="transfer_by" value="Self">
			        	<div class="form-group">
			        		<button onclick="return confirm('Are you sure to Delete Permanently?')" class="btn btn-danger btn-sm" type="submit">Delete</button>
			        	</div>
			        </form>
				<?php endif; ?>
			<?php endif; ?>

		</div>
	</div>

	<div class="details--wrapper">
		<?php if(Request::is('admin/in-progress')): ?>
		<div class="text-right">
			<button type="button" class="reply__btn btn btn-primary"
				toEmail="<?php echo e($content->email); ?>" toName="<?php echo e($content->full_name); ?>">Reply
			</button>
			<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#adminListModal_solved-<?php echo e($content->id); ?>">
			  Solved
			</button>
			<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#adminListModal_trashed-<?php echo e($content->id); ?>">
			  Trash
			</button>
		</div>
		<?php endif; ?>

		<?php if(Request::is('admin/solved')): ?>
		<div class="text-right">
			<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#adminListModal_trashed-<?php echo e($content->id); ?>">
			  Trash
			</button>
		</div>
		<?php endif; ?>


		<?php if(!Request::is('admin/inbox')): ?>
		<div class="text-right">
			<small><span><?php echo e($content->status); ?> By : <?php if(intval($content->get_transfer_by->id) === Auth::user()->id): ?> <?php echo e('Self'); ?> <?php else: ?> <?php echo e($content->get_transfer_by->name); ?> <?php endif; ?></span></small>
		</div>
		<?php endif; ?>

		<div class="table-responsive no--boder-tbl">
			<table class="table">
				<tr>
					<th colspan="2">Summary</th>
				</tr>
				<tr>
					<th>Full Name</th>
					<td><?php echo e($content->full_name); ?></td>
				</tr>


				<?php if($content->registration_type === "Other"): ?>
				<tr>
					<th>Request By</th>
					<td><?php echo e($content->you_are); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($content->registration_type !== "Other"): ?>
					<tr>
						<th>Degree</th>
						<td><?php echo e($content->degree); ?></td>
					</tr>

					<?php if($content->degree === "Bachelor"): ?>
					<tr>
						<th>Learning System</th>
						<td><?php echo e($content->learning_stream); ?></td>
					</tr>
					<?php endif; ?>

					<?php if($content->degree === "Master"): ?>
					<tr>
						<th>Master Name</th>
						<td><?php echo e($content->master_name); ?></td>
					</tr>
					<?php endif; ?>

					<tr>
						<th>Year</th>
						<td><?php echo e($content->year); ?></td>
					</tr>

					<?php if($content->registration_type === "Student" && $content->degree === "Bachelor"): ?>
					<tr>
						<th>Group</th>
						<td><?php echo e($content->group); ?></td>
					</tr>
					<?php endif; ?>
				<?php endif; ?>


				<tr>
					<th>Email</th>
					<td><?php echo e($content->email); ?></td>
				</tr>
				<tr>
					<th>Telephone</th>
					<td><?php echo e($content->telephone); ?></td>
				</tr>
				<tr>
					<th>Request Type</th>
					<td><?php echo e($content->request_type); ?></td>
				</tr>
				<tr>
					<th>Message</th>
					<td>
						<div>
							<?php echo e($content->message); ?>

						</div>
					</td>
				</tr>
				<tr>
					<th>Status</th>
					<td>
						<span class="badge badge-danger"><?php echo e($content->status); ?></span>
					</td>
				</tr>
				<tr>
					<th>Request at</th>
					<td>
						<?php echo e($content->created_at->format('d/m/Y')); ?>

					</td>
				</tr>

				<?php if($content->request_file != NULL): ?>
				<tr>
					<th>Attachment's</th>
					<td>
						<a target="_blank" href="<?php echo e(route('admin.viewFile.get', [$content->id, $content->request_file])); ?>">
						<i class="fas fa-paperclip"></i> View Attachment
						</a>
					</td>
				</tr>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>





<!-- Modal -->
<div class="modal fade" id="adminListModal_in_progress-<?php echo e($content->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel-<?php echo e($content->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel-<?php echo e($content->id); ?>">Transfer By</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.moveTo.post', $content->id)); ?>" method="POST">
        	<?php echo csrf_field(); ?>
        	<input type="hidden" name="move_to" value="In progress">
        	<div class="form-group">
        		<select name="transfer_by" class="form-control">
        			<option value="">Choose One</option>
        			<option value="Self">Self</option>
        			<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</select>
        	</div>
        	<div class="form-group">
        		<button onclick="return confirm('Are you sure to move to In progress?')" class="btn btn-primary btn-sm" type="submit">Transfer</button>
        	</div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="adminListModal_solved-<?php echo e($content->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel1-<?php echo e($content->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Transfer By</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.moveTo.post', $content->id)); ?>" method="POST">
        	<?php echo csrf_field(); ?>
        	<input type="hidden" name="move_to" value="Solved">
        	<div class="form-group">
        		<select name="transfer_by" class="form-control">
        			<option value="">Choose One</option>
        			<option value="Self">Self</option>
        			<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</select>
        	</div>
        	<div class="form-group">
        		<button onclick="return confirm('Are you sure to move to Solved?')" class="btn btn-primary btn-sm" type="submit">Transfer</button>
        	</div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="adminListModal_trashed-<?php echo e($content->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel1-<?php echo e($content->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1-<?php echo e($content->id); ?>">Transfer By</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.moveTo.post', $content->id)); ?>" method="POST">
        	<?php echo csrf_field(); ?>
        	<input type="hidden" name="move_to" value="Trash">
        	<div class="form-group">
        		<select name="transfer_by" class="form-control">
        			<option value="">Choose One</option>
        			<option value="Self">Self</option>
        			<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</select>
        	</div>
        	<div class="form-group">
        		<button onclick="return confirm('Are you sure to move to Trash?')" class="btn btn-primary btn-sm" type="submit">Transfer</button>
        	</div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/Pages/partials/request-details.blade.php ENDPATH**/ ?>