

<?php $__env->startSection('adminContent'); ?>      
<?php echo $__env->make('BackendViews.Admin.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <!-- yield content here -->
    <div class="col-md-12 grid-margin">
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-between">
            <h4 class="card-title mb-0">Inbox</h4>
          </div>
          <p class="card-description">This page represent all new requests</p>
          <br>
          <?php echo $__env->make('msg.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


          <div class="row">
            <div class="col-3">
              <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-link <?php if($key == 0): ?> active <?php endif; ?>" id="v-pills-home-tab-<?php echo e($content->id); ?>" data-toggle="pill" href="#v-pills-home-<?php echo e($content->id); ?>" role="tab" aria-controls="v-pills-home-<?php echo e($content->id); ?>" aria-selected="<?php if($key ==0): ?>true <?php else: ?> false <?php endif; ?>">
                  <?php echo e($content->registration_type); ?> #<?php echo e($content->request_id); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <div class="col-9">
              <div class="tab-content" id="v-pills-tabContent">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($key == 0): ?>show active <?php endif; ?>" id="v-pills-home-<?php echo e($content->id); ?>" role="tabpanel" aria-labelledby="v-pills-home-tab-<?php echo e($content->id); ?>">
                  <?php echo $__env->make('BackendViews.Admin.Pages.partials.request-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>

            


          <?php echo $data->render(); ?>

        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('adminScripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('BackendViews.Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/Pages/inbox.blade.php ENDPATH**/ ?>