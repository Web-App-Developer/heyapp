

<?php $__env->startPush('backend_css'); ?>
<link rel="stylesheet" type="text/css" href="/processing/form-processing-style.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('adminContent'); ?>      
<?php echo $__env->make('BackendViews.Admin.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <!-- yield content here -->
    <div class="col-md-12 grid-margin">
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-between">
            <h4 class="card-title mb-0">Manage Admins</h4>
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addAdminModal">
              Add
            </button>
          </div>
          <p class="card-description">This page represent admin management.</p>
          <br>
          <?php echo $__env->make('msg.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>SN.</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Created at</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if(!$data->isEmpty()): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key+1); ?></td>
                  <td><?php echo e($content->name); ?></td>
                  <td><?php echo e($content->email); ?></td>
                  <td><?php echo e($content->created_at->format('d/m/Y')); ?></td>
                  <td>
                    <?php echo $__env->make('BackendViews.Admin.Pages.admins-partials.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('BackendViews.Admin.Pages.admins-partials.update-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')" href="<?php echo e(route('admin.deleteAdmin.post', encrypt($content->id))); ?>"><i class="fas fa-trash"></i></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <?php echo $data->render(); ?>

                </tr>

                <?php endif; ?>


              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addAdminModal" tabindex="-1" aria-labelledby="exampleModalLabelAdmin" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabelAdmin">Add New Admin</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="<?php echo e(route('admin.admins.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label>* Name</label>
                <input type="text" name="name" placeholder="Name" class="form-control">
              </div>
              <div class="form-group">
                <label>* Email</label>
                <input type="email" name="email" placeholder="Email" class="form-control">
              </div>
              <div class="form-group">
                <label>Note</label>
                <input type="text" name="note" placeholder="Note (Optional)" class="form-control" maxlength="200">
              </div>
              <div class="form-group">
                <label>* Password</label>
                <input type="password" name="password" placeholder="Password" class="form-control">
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-sm">Add</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>



    <?php echo $__env->make('BackendViews.Admin.Pages.partials.reply-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('processing.processing-gif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('adminScripts'); ?>
<script type="text/javascript">
  //reply template
  $(".reply__btn").on('click', function(){
    let toEmail = $(this).attr('toEmail')
    let toName = $(this).attr('toName')

    if (toEmail != "" && toName != "") {
      $("#setToName").val(toName)
      $("#setToName").attr('readonly', true)
      
      $("#setToEmail").val(toEmail)
      $("#setToEmail").attr('readonly', true)

      $("#getReplyTemplate").modal('show');
    }else{
      alert('Invalid Request')
      window.location.reload(true)
    }

  })
</script>

<script type="text/javascript" src="/assets/js/main.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('BackendViews.Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/Pages/users.blade.php ENDPATH**/ ?>