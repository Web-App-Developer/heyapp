

<?php $__env->startSection('adminContent'); ?>      
<?php echo $__env->make('BackendViews.Admin.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
<!-- yield content here -->
<h3 class="text-center"><b>Welcome</b>- Admin, have a good day!</h3>
	
	
	<?php
	    $getTotal = (\App\OnlineRegistration::get());
	    $getTotalNew = (\App\OnlineRegistration::where('status', 'New')->count());
	    $getTotalInProgress = (\App\OnlineRegistration::where('status', 'In progress')->count());
	    $getTotalSolved = (\App\OnlineRegistration::where('status', 'Solved')->count());
	    $getTotalTrash = (\App\OnlineRegistration::where('status', 'Trash')->count());
	?>
	
    <div class="table-responsive" style="margin-top: 40px">
    	<table class="table" style="text-align: center !important;">
    		<thead style="background: #ddd; border-bottom: 3px solid #444;">
    			<tr>
    				<th>Total</th>
    				<th>Inbox</th>
    				<th>In Progress</th>
    				<th>Solved</th>
    				<th>Trashed</th>
    			</tr>
    		</thead>
    		<tbody>
    			<td><?php echo e(count($getTotal)); ?></td>
    			<td><?php echo e($getTotalNew); ?></td>
    			<td><?php echo e($getTotalInProgress); ?></td>
    			<td><?php echo e($getTotalSolved); ?></td>
    			<td><?php echo e($getTotalTrash); ?></td>
    		</tbody>
    	</table>
    </div>

<?php $__env->stopSection(); ?>     
<?php echo $__env->make('BackendViews.Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online_registration\resources\views/BackendViews/Admin/dashboard.blade.php ENDPATH**/ ?>